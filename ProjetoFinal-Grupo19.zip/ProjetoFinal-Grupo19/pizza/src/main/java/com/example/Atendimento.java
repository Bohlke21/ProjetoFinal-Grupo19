package com.example;

public class Atendimento {

    private static int contador = 1;
    private int numeroAtendimento;
    private ListaDeProdutos produtos;
    private String status;

    public Atendimento(ListaDeProdutos produtos) {
        this.numeroAtendimento = contador++;
        this.produtos = produtos;
        this.status = "Em preparo";
    }

    public int getNumeroAtendimento() {
        return numeroAtendimento;
    }

    public ListaDeProdutos getProdutos() {
        return produtos;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Atendimento #" + numeroAtendimento + "\n" +
                produtos.toString() + "\n" +
                "Status: " + status;
    }
}