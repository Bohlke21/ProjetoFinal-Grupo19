package com.example;

public class Bebida extends Itens {

    public Bebida(String tipo, double valor) {
        super(tipo, valor);    
    }
}