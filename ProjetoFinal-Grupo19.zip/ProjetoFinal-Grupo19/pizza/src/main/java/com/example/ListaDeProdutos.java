package com.example;

import java.util.LinkedList;

public class ListaDeProdutos {

    private LinkedList<Itens> produtos = new LinkedList<>();

    public void adicionarProduto(Itens item) {
        produtos.add(item);
    }

    public void removerProduto(Itens item) {
        produtos.remove(item);
    }

    public void removerTodosProduto() {
        produtos.clear();
    }

    @Override
    public String toString() {
        if (produtos.isEmpty()) {
            return "🛒 Carrinho vazio";
        }

        StringBuilder sb = new StringBuilder("🛒 Produtos no carrinho:\n");
        double total = 0;

        for (Itens p : produtos) {
            sb.append("- ").append(p.getTipo())
            .append(" | R$ ").append(p.getValor())
            .append("\n");
            total += p.getValor();
        }

        sb.append("\n💰 Total: R$ ").append(total);
        return sb.toString();
    }
}