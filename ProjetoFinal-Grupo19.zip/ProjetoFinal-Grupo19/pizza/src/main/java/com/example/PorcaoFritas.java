package com.example;

public class PorcaoFritas extends Itens{

    public PorcaoFritas(String tipo, double valor) {
        super(tipo, valor);  
    }
}