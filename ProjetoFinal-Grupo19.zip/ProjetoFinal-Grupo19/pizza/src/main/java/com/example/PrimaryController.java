package com.example;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import java.util.ArrayList;
import java.util.List;

public class PrimaryController {

    Xis xis1 = new Xis("Xis de Coração", 32.50);
    Xis xis2 = new Xis("Xis de Calabresa", 30.00);
    Xis xis3 = new Xis("Xis de Filé", 35.00);
    Xis xis4 = new Xis("Xis Salada", 25.00);

    PorcaoFritas porcao1 = new PorcaoFritas("Porção de Fritas com Coração", 35.00);
    PorcaoFritas porcao2 = new PorcaoFritas("Porção de Fritas com Filé", 40.00);

    Bebida bebida1 = new Bebida("Coca-Cola", 6.00);
    Bebida bebida2 = new Bebida("Guaraná", 5.00);

    private ListaDeProdutos carrinho = new ListaDeProdutos();
    private List<Atendimento> atendimentosRealizados = new ArrayList<>();


    @FXML
    TextArea tfLista, tfEstabelecimento;
        
    @FXML
    Button AdicionarCarrinho1, AdicionarCarrinho2, AdicionarCarrinho3, AdicionarCarrinho4, AdicionarCarrinho5, AdicionarCarrinho6, AdicionarCarrinho7, AdicionarCarrinho8;

    @FXML
    Button RemoverCarrinho1, RemoverCarrinho2, RemoverCarrinho3, RemoverCarrinho4, RemoverCarrinho5, RemoverCarrinho6, RemoverCarrinho7, RemoverCarrinho8;

    @FXML
    Button RemoverTudo, ConfirmarCarrinho, StatusPronto, StatusEntregue;

    @FXML
    public void metodosCarrinho(ActionEvent event) {
        Button botaoClicado = (Button) event.getSource();

        if (botaoClicado == AdicionarCarrinho1) {
            carrinho.adicionarProduto(xis1);
        }

        if (botaoClicado == AdicionarCarrinho2) {
            carrinho.adicionarProduto(xis2);
        }
       
        if (botaoClicado == AdicionarCarrinho3) {
            carrinho.adicionarProduto(xis3);
        }

        if (botaoClicado == AdicionarCarrinho4) {
            carrinho.adicionarProduto(xis4);
        }

        if (botaoClicado == AdicionarCarrinho5) {
            carrinho.adicionarProduto(porcao1);
        }

        if (botaoClicado == AdicionarCarrinho6) {
            carrinho.adicionarProduto(porcao2);
        }

        if (botaoClicado == AdicionarCarrinho7) {
            carrinho.adicionarProduto(bebida1);
        }

        if (botaoClicado == AdicionarCarrinho8) {
            carrinho.adicionarProduto(bebida2);
        }

        if (botaoClicado == RemoverCarrinho1) {
            carrinho.removerProduto(xis1);
        }

        if (botaoClicado == RemoverCarrinho2) {
            carrinho.removerProduto(xis2);
        }

        if (botaoClicado == RemoverCarrinho3) {
            carrinho.removerProduto(xis3);
        }

        if (botaoClicado == RemoverCarrinho4) {
            carrinho.removerProduto(xis4);
        }

        if (botaoClicado == RemoverCarrinho5) {
            carrinho.removerProduto(porcao1);
        }

        if (botaoClicado == RemoverCarrinho6) {
            carrinho.removerProduto(porcao2);
        }

        if (botaoClicado == RemoverCarrinho7) {
            carrinho.removerProduto(bebida1);
        }

        if (botaoClicado == RemoverCarrinho8) {
            carrinho.removerProduto(bebida2);
        }

        if (botaoClicado == RemoverTudo) {
            carrinho.removerTodosProduto();
        }

        if (botaoClicado == ConfirmarCarrinho) {
            Atendimento atendimento = new Atendimento(carrinho);
            atendimentosRealizados.add(atendimento);
            tfLista.setText("\n ✅ Pedido Confirmado\n\n" + atendimento.toString());
            atualizarTextAreaEstabelecimento();
            carrinho = new ListaDeProdutos();
            return;
        }

        tfLista.setText(carrinho.toString());
    }

    @FXML
    public void atualizarStatus(ActionEvent event) {
        if (atendimentosRealizados.isEmpty()) return;

        Atendimento ultimo = atendimentosRealizados.get(atendimentosRealizados.size() - 1);

        if (event.getSource() == StatusPronto) {
            ultimo.setStatus("Pronto ✅");
        }

        if (event.getSource() == StatusEntregue) {
            ultimo.setStatus("Entregue 🚚");
        }

        atualizarTextAreaEstabelecimento();
        atualizarTextAreaLista();
    }

    @FXML
    private void atualizarTextAreaEstabelecimento() {
        StringBuilder sb = new StringBuilder();
        for (Atendimento a : atendimentosRealizados) {
            sb.append(a).append("\n\n");
        }
        tfEstabelecimento.setText(sb.toString());
    }

    @FXML
    private void atualizarTextAreaLista() {
        if (atendimentosRealizados.isEmpty()) 
            return;
        Atendimento atual = atendimentosRealizados.get(atendimentosRealizados.size() - 1);
        tfLista.setText(atual.toString());
    }
}