package com.example;

public class Xis extends Itens{

    public Xis(String tipo, double valor) {
        super(tipo, valor);  
    }
}